//
//  ApiCoinCapApp.swift
//  ApiCoinCap
//
//  Created by Andre Gerez Foratto on 12/04/24.
//

import SwiftUI

@main
struct ApiCoinCapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
