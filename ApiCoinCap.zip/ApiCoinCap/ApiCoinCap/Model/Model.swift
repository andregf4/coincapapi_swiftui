//
//  Model.swift
//  ApiCoinCap
//
//  Created by Andre Gerez Foratto on 12/04/24.
//

import Foundation
import SwiftUI

struct ApiData: Decodable {
    let data: [Moeda]
}

struct ApiMoeda: Decodable {
    let data: Moeda?
}

struct Moeda: Codable, Identifiable {
    let id: String?
    let rank: String?
    let symbol: String?
    let name: String?
    let supply: String?
    let maxSupply: String?
    let marketCapUsd: String?
    let volumeUsd24Hr: String?
    let priceUsd: String?
    let changePercent24Hr: String?
    let vwap24Hr: String?
    let explorer: String?
}
