//
//  MoedaView.swift
//  ApiCoinCap
//
//  Created by Andre Gerez Foratto on 12/04/24.
//

import SwiftUI

struct MoedaView: View {
    
    @StateObject var viewModel = ViewModel()
    @State var cor: LinearGradient = LinearGradient(colors: [.black, .yellow, .black], startPoint: .top, endPoint: .bottom)
    
    var coin: Moeda
    
    @State var resposta: Double = 0.0
    @State var showPreco: Bool = false
    
    var body: some View {
        
        ZStack {
            
            cor
            
            VStack {
                
                VStack {
                    VStack {
                        Text("1 \(coin.id!) equivale a quantos dólares?")
                            .bold()
                        Text("Ganha se errar por menos de 5%...")
                    }
                    .padding()
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(LinearGradient(colors: [.black, .gray, .black], startPoint: .top, endPoint: .bottom), lineWidth: 4)
                    )
                    .background(.yellow)
                }
                .padding(.top, 180)
                
                Spacer()
                
                Text(coin.symbol!)
                    .font(.title)
                    .bold()
                    .fontDesign(.serif)
                
                VStack {
                    Text(coin.name!).font(.system(size: 24))
                    Text(.init("[Explorer](\(coin.explorer!))"))
                        .padding(3)
                        .overlay(
                            RoundedRectangle(cornerRadius: 2)
                                .stroke(.black, lineWidth: 2)
                        )
                        .background(.black)
                }
                .fontWeight(.light)
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 5)
                        .stroke(LinearGradient(colors: [.black, .gray, .black], startPoint: .top, endPoint: .bottom), lineWidth: 4)
                )
                .shadow(radius: 10)
                .padding(10)
                
                Spacer()
                
                VStack {
                    HStack {
                        TextField("Resposta...", value: $resposta, formatter: NumberFormatter())
                            .multilineTextAlignment(.center)
                            .padding()
                            .overlay(
                                RoundedRectangle(cornerRadius: 5)
                                    .stroke(LinearGradient(colors: [.black, .gray, .black], startPoint: .top, endPoint: .bottom), lineWidth: 4)
                            )
                            .background(.white)
                        
                        Button() {
                            withAnimation(.easeIn(duration: 2)) {
                                calculoPriceUSD()
                            }
                        } label: {
                            Text("OK").bold()
                                .padding()
                                .background(.black)
                                .clipShape(RoundedRectangle(cornerSize: CGSize(width: 10, height: 10)))
                        }
                    }
                    .padding([.leading, .trailing], 100)
                    
                    if showPreco {
                        let precoDouble = Double(coin.priceUsd!)!
                        
                        VStack {
                            HStack {
                                Text("Atual valor: ").bold()
                                Text("\(precoDouble, specifier: "%.2f")")
                                    .underline(color: .yellow)
                                Text("dólar(es).")
                            }
                            .foregroundStyle(.white)
                            .padding(.top, 10)
                        }
                    }
                }
                .padding(.bottom, 180)
            }
            Text(coin.rank!)
                .font(.system(size: 300))
                .opacity(0.15)
        }
        .ignoresSafeArea()
    }
    
    func calculoPriceUSD() {
        if Double(coin.priceUsd!) != nil {
            if (resposta >= (Double(coin.priceUsd!)! - 0.05*Double(coin.priceUsd!)!)) && (resposta <= (Double(coin.priceUsd!)! + 0.05*Double(coin.priceUsd!)!)) {
                showPreco.toggle()
                cor = LinearGradient(colors: [.black, .green, .black], startPoint: .top, endPoint: .bottom)
            } else {
                cor = LinearGradient(colors: [.black, .red, .black], startPoint: .top, endPoint: .bottom)
                showPreco.toggle()
            }
        }
    }
}

#Preview {
    MoedaView(coin: Moeda(id: "bitcoin", rank: "2", symbol: "SYBM", name: "Name", supply: "", maxSupply: "", marketCapUsd: "", volumeUsd24Hr: "", priceUsd: "", changePercent24Hr: "", vwap24Hr: "", explorer: ""))
}
