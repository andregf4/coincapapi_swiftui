//
//  ViewModel.swift
//  ApiCoinCap
//
//  Created by Andre Gerez Foratto on 12/04/24.
//

import Foundation

class ViewModel: ObservableObject {
    
    @Published var moedas: [Moeda] = []
    
    func fetch() {
        
        guard let url = URL(string: "https://api.coincap.io/v2/assets") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode(ApiData.self, from: data)
                DispatchQueue.main.async {
                    self?.moedas = parsed.data
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
}
