//
//  ContentView.swift
//  ApiCoinCap
//
//  Created by Andre Gerez Foratto on 12/04/24.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var viewModel = ViewModel()
    
    @State var cor: LinearGradient = LinearGradient(colors: [.black, .yellow, .black], startPoint: .top, endPoint: .bottom)
    
    var body: some View {
        NavigationStack {
            ZStack {
                cor
                VStack {
                    
                    Text("Coincap Api 2.0")
                        .font(.system(size: 25))
                        .bold()
                        .frame(width: 215, height: 70)
                        .overlay(
                            RoundedRectangle(cornerRadius: 5)
                                .stroke(.yellow, lineWidth: 4)
                        )
                        .background(.yellow)
                        .shadow(radius: 2)
                        .padding(.bottom, 10)
                    
                    List(viewModel.moedas) { m in
                        Section {
                            NavigationLink(destination: MoedaView(coin: m)) {
                                Text("Nome: " + m.name!)
                            }
                            Text("Ranking: " + m.rank!)
                            Text("Símbolo: " + m.symbol!)
                            HStack {
                                Text("Oscilação: ")
                                if (Double(m.changePercent24Hr!)! < 0) {
                                    Image(systemName: "minus.circle.fill")
                                        .foregroundStyle(.red)
                                } else {
                                    Image(systemName: "plus.circle.fill")
                                        .foregroundStyle(.green)
                                }
                            }
                        }
                    }
                    .scrollContentBackground(.hidden)
                }
                .frame(width: 250, height: 670)
                .onAppear() {
                    viewModel.fetch()
                }
            }
            .ignoresSafeArea()
        }.accentColor(.yellow)
    }
}

#Preview {
    ContentView()
}
